import React, { useState, useEffect, useContext } from "react";
import CardDetail from "../molecules/card";
import { Button, Grid } from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import { bookContext } from "../../bookcontext";

const useStyles = makeStyles({
  root: {
    display: "flex",
    flexWrap: "wrap",
  },
  finished: {
    width: "80%",
    margin: "10%",
    marginTop: "0",
  },
});

const finished = [
  {
    index: 0,
    duration: 10,
    author: "Rebecca ",
    title: "Reimagining ",
    image:
      "https://images.blinkist.io/images/books/5f76e2276cee070007d0480d/1_1/640.jpg",
  },
];

const entrepreneurship = [
  {
    index: 0,
    duration: 10,
    author: "Rebecca ",
    title: "Reimagining ",
    image:
      "https://images.blinkist.io/images/books/55914c9030383300070a0000/1_1/470.jpg",
  },
];

export type  populateValues = {
    value: number
  };
  
  export default Populate;
  

function Populate(props:populateValues) {
  // const context = useContext(bookContext);
  const classes = useStyles();
  const { value } = props;
  const booksArray = [{
    "bookId" : 1,
    "bookName" : "dxfdxxgxg",
    "authorName" : "erfsxgxcx",
    "status" : true,
    "time" : 9,
    "url" :"https://images.blinkist.io/images/books/596caa5fb238e1000517dcd8/1_1/470.jpg"
}];
  
  return (
    <>
      <div data-testid="populate">
        <Grid container justifyContent="center">
        </Grid>
        <Grid item xs={12}>
          <div className={classes.root}>
            {booksArray.map((book,index) => {
              return (
                <React.Fragment key={index}>
                  <Grid item xs={4}>
                    <CardDetail
                      duration={book.time}
                      author={book.authorName}
                      title={book.bookName}
                      image={book.url}
                    ></CardDetail>
                  </Grid>
                </React.Fragment>
              );
            })}
          </div>
        </Grid>
      </div>
    </>
  );
};

