import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import { Grid } from '@material-ui/core';
import Populate from './populate';


const tabUseStyles=makeStyles({
  root:{
  justifyContent:"center",
  
  },


})

export const TabCheck=()=> {
  const [value, setValue] = React.useState(0);
  const classes=tabUseStyles();
  function handleChange(event:any, newValue:any){
    console.log("new vlaue in  tab : ",newValue);
    setValue(newValue);
  }

  return (
    <>
    <Grid container justifyContent="center">
    <Grid item xs={6} className={classes.root}>
      
      <br></br>
      <h1 >My Library</h1>
      <Tabs
        value={value}
        onChange={handleChange}
        indicatorColor="primary"
        textColor="primary"       
      >
        <Tab label="Currently Reading" />
        <Tab label="Finished" />
        
      </Tabs>
    
    </Grid>
    </Grid>
   
    <Grid container justifyContent="center" >
    <Grid item xs={6} className={classes.root} >
    <Populate  value={value} ></Populate>
    </Grid>
    </Grid>
    </>
  );
}

