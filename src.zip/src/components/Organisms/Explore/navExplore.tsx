import withStyles from "@material-ui/styles/withStyles";
import { autocompleteClasses } from "@mui/material";
import { createStyles } from "@mui/styles";
import React from "react";
import { NavExploreList } from "../../molecules/explore";
// import cssStyles from './styles.modules.css';


const cssStyles : any =  withStyles({
    box : {
        background : '#f1f6f4',
        width: '100vw',
        height : "auto",
        position : "fixed",
        zIndex:2,
        top : "4rem"
    },
    box_content : {
        width : "62%",
        margin:"auto",
        height : "100%"
    },
    category:{
        borderBottom : "black 1px solid",
        padding: "1.5rem 0",
        color : "var(--light-gray)",
        fontSize : "1.2rem",
        // fontWeight : "600",
        display : "grid",
        gridAutoFlow : "column",
        },
    span : {
            color: "#116be9",
        }
        
    
});

export  function ExploreNav(){ 
    return (
        <div className={cssStyles.box}>
            <div className={cssStyles.box_content}>
                <div className={cssStyles.category}>
                    <span>Explore By Category</span>
                    <span>See recently added titles</span>
                    <span>See popular titles</span>
                </div>
                <div className={cssStyles.quick_links}>
                    <NavExploreList />
                    <NavExploreList />
                    <NavExploreList />
                </div>
            </div>
        </div>
    );
};

