import React from "react";
import withStyles from "@material-ui/styles/withStyles";
import { MainIcon } from "../atoms/LogoIcon";
import AppStore from "../../assets/images/AppStore.png"
import PlayStore from "../../assets/images/PlayStore.png"

// import QuickList from "../../Molecules/QuickList";

 const footerUseStyles:any = withStyles({
    footer: {
        marginTop: "3rem",
        width: "100vw",
        background: "#f1f6f4",
        height: "45vh",
        justifyContent: "center",
    },

    footerBox: {
        width: "60%",
        height: "auto",
        margin: "auto",
        display: "grid",
        padding: "2rem",
        gridTemplateRows: "80% 20%",
        gridTemplateColumns: "40% 60%",
    },

    top_1_text: {
        display: "flex",
        flexDirection: "column",
        margin: "1.5rem 0",
        // fontWeight: "700",
        fontSize: "1.3rem",
        color: "#226be9",
    },

    top_2: {
        display: "flex",
        justifyContent: "space-evenly",
    },

    images: {
        width: "8rem",
    },

    boxBottom: {
        padding: "2rem 0 0 0",
        gridColumn: "span 2",
        fontSize: "0.8rem",
        color: "var(--light-gray)",
    },
});

export function Footer(){
 
    const footerClasses = footerUseStyles();

    return (
        <div className={footerClasses.footer} data-testid="footer">
            <div className={footerClasses.footerBox}>
                <div >
                    <div >
                        <MainIcon />
                        <div className={footerClasses.top_1_text}>
                            <span>Big ideas in small packages</span>
                            <span>Start learning now</span>
                        </div>
                        <div>
                            <img
                                className={footerClasses.images}
                                alt=""
                                src={AppStore}
                            />
                            <img
                                className={footerClasses.images}
                                alt=""
                                src={PlayStore}
                            />
                        </div>
                    </div>
                </div>
                {/* <div className={footerClasses.top_2}>
                    {quickLists.map((quickList, index) => (
                        <QuickList
                            key={`quickList__${index}`}
                            items={quickList}
                        />
                    ))}
                </div> */}
                <div className={footerClasses.boxBottom}>
                    <span>
                        Blinkist 2021 | Sitemap | Disclaimer | Terms Of Service
                        | Privacy Policies
                    </span>
                </div>
            </div>
        </div>
    );
};

