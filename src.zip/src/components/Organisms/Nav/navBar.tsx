import Grid from "@material-ui/core/Grid";
import withStyles from "@material-ui/styles/withStyles";
import { ButtonField } from "../../atoms/button";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import SearchIcon from "@material-ui/icons/Search";
import { MainIcon } from "../../atoms/LogoIcon";
import { CustomSearchIcon } from "../../atoms/searchIcon";

export function Nav() {   
   const Navclasses:any = withStyles({
    root: {
        justifyContent: "center",
        display : "flex"
    },
    navSpace: {
        display: "flex",
        flexGrow: 1,
        alignItems: "center",
        flexWrap:"wrap",
        flexDirection : "column",
    },
    ul: {
        display: "flex",
        flexWrap: "wrap",
        listStyleType: "none",
        width: "100%",
        alignItems: "center",
    },
    nav: {
        display: "flex",
        flexWrap: "wrap",
        alignItems: "center",
        flexDirection : "column",
    },
    inputText: {
        marginLeft: "10px",
        width: "100%",
        maxWidth: "300px",
    },
});

    return (
            <Grid container justifyContent = "center"  >
                <Grid item xs={7} className={Navclasses.root} direction = "column">
                    <div className = {Navclasses.navSpace}>
                    <div className={Navclasses.nav}>
                        <ul className={Navclasses.ul} >
                            <li className={Navclasses.list}>
                                <div className="header_logo">
                                    <MainIcon
                                    />
                                </div>
                            </li>
                            <li className="list">
                                <CustomSearchIcon>
                                    <SearchIcon></SearchIcon>
                                </CustomSearchIcon>
                            </li>
                           
                            <li
                                style={{
                                    marginLeft: "auto",
                                    paddingRight: "10px",
                                }}
                                className="list"
                            >
                                <ButtonField
                                    className="contained"
                                    variant="contained"
                                    color="primary"
                                >
                                    Upgrade To Premium
                                </ButtonField>
                            </li>

                            <li className="list">
                                <ButtonField
                                    className="dropdown"
                                    endIcon={<ExpandMoreIcon />}
                                    
                                >
                                </ButtonField>
                            </li>
                        </ul>
                    </div>
                    </div>
                </Grid>
            </Grid>);
}

