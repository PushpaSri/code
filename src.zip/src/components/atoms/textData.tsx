import {Typography , TypographyProps} from "@material-ui/core";
import React from "react";

interface typoProps extends TypographyProps{

}

export const  TextData : React.FC<typoProps> = ({variant,children}) =>{
    return (
        <Typography data-testid="text" variant={variant} >
            {children}
        </Typography>
    );
}



