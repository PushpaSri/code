import React from "react";
import {Button , ButtonProps} from "@material-ui/core";

interface buttonFieldProps extends ButtonProps {
    
}


export function ButtonField (props : buttonFieldProps) {    
    return (
        <Button
            data-testid="button"
            variant={props.variant}
            color ={props.color}
            onClick={props.onClick}
        >
            {props.children}
        </Button>
    );
};

