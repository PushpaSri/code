import React from "react";
import { IconButton } from "@mui/material";
import { IconButtonProps } from "@mui/material";

interface iconProps extends IconButtonProps{

}


export const CustomSearchIcon : React.FC<iconProps> = ({ children,onClick }) => {
    return (
        <IconButton onClick={onClick} className='header_middle' aria-label="search">
        {children}
      </IconButton>
    )
}

