import { Label } from "@mui/icons-material";
import { Button , ButtonProps, makeStyles } from "@mui/material";
import CSS from 'csstype';

// const useStyles = makeStyles(() => ({
//   ,
//   startIcon: {
//     color: "#052330",
//   },
// }));

const textStyles : CSS.Properties =  {
    textTransform: "capitalize",
    color: "#6d787e",
    fontSize: "1rem",
}


  interface Props extends ButtonProps{

  }


export const NavDrop : React.FC<Props> = ({startIcon,onClick,title,className,classes,children}) => {
  return (
    <Button
    startIcon={startIcon}
    data-testid="expand"
    onClick={onClick}
    style={textStyles}
  >
    {title}
    </Button>
  );
};



