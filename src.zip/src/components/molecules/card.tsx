import { TextData } from "../atoms/textData";
import Card from "@material-ui/core/Card";
import { makeStyles } from "@material-ui/core/styles";
import CardContent from "@material-ui/core/CardContent";
import React from "react";
import PropTypes from "prop-types";
import { CardProps } from "@mui/material";

const useStyles = makeStyles({
    title: {
        fontFamily: "CeraPRO",
        fontSize: "1.125rem",
        maxWidth: "25rem",
        // fontWeight : '700',
        lineHeight: "1.33",
        marginBottom: "0.5rem",
        flexWrap: "wrap",
    },
    author: {
        fontFamily: "CeraPRO",
        fontSize: "1rem",
        maxWidth: "25rem",
        // fontWeight: "500",
        lineHeight: "1.5",
        marginBottom: "0.5rem",
        flexWrap: "wrap",
        color: "#6D787E",
    },
    duration: {
        fontFamily: "CeraPRO",
        fontSize: "0.875rem",
        maxWidth: "25rem",
        // fontWeight: "400",
        lineHeight: "1.57",
        marginBottom: "0.5rem",
        flexWrap: "wrap",
        color: "#3A4649",
    },
    image: {
        width: "100%",
        margin: "0",
        padding: "0",
    },

    content: {
        borderColor: "black",
        margin: "10%",
        marginBottom: "0",
    },
    clockImage: {
        marginRight: "3%",
        marginTop: "4%",
    },
});


interface cardProps{
    duration ?: number,
    author ?: string,
    title ?: string,
    image ?:string,

}




export default function  CardDetail(props:cardProps) {
    const Cardclasses = useStyles();
    return (
        <Card className={Cardclasses.content} data-testid="card">
            <CardContent>
                <img className={Cardclasses.image} src={props.image} alt="Book"></img>

                <div className={Cardclasses.content}>
                    <TextData className={Cardclasses.title} variant="h6">
                        {props.title}
                    </TextData>
                    <TextData className={Cardclasses.author} variant="subtitle1">
                        {props.author}
                    </TextData>
                    <TextData variant="body1" className={Cardclasses.duration} >
                        <img
                            className={Cardclasses.clockImage}
                            src="https://d17pjsg7x52x9r.cloudfront.net/assets/components/book_card/clock-b0e2e0235fbe1df824d662b2b3b96611e3711bf5b5c7556b8bd3828720f86dbc.svg"
                            alt="clock"
                        ></img>
                        {`${props.duration} min read`}
                    </TextData>
                </div>
            </CardContent>
        </Card>
    );
};

