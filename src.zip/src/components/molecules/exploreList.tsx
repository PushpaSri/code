import React from "react";
// import { makeStyles } from "@material-ui/core";

// const useStyles = makeStyles({
//     list_items: {
//         padding: "0",
//     },
//     list_item: {
//         listStyle: "none",
//         margin: "0.5rem 0",
//         color: "var(--light-gray)",
//         fontSize: "0.8rem",
//         fontWeight: "bold",
//         marginBottom: "1rem",
       
//     },
// });

// export function ExploreList(props) {
//     const classes = useStyles();
//     return (
//         <ul data-testid="quicklist" className={classes.quicklist_items}>
//             {props.items && props.items.map((item, index) => (
//                 <li
//                     key={"quick_list_item" + index}
//                     className={classes.quicklist_item}
//                 >
//                     {item}
//                 </li>
//             ))}
//         </ul>
//     );
// };

// interface QuickList {
//     items?: Array[string],
// };

// export default QuickList;
