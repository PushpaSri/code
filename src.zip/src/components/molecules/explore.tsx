import React from "react";
import {
    AccountBalanceOutlined,
    BusinessCenterOutlined,
    EcoOutlined,
    HourglassEmptyOutlined,
    LocalHospitalOutlined,
    PublicOutlined,
} from "@material-ui/icons";
import { NavDrop } from "../atoms/dropdown";
import { makeStyles } from "@material-ui/core/styles";

const useStyles = makeStyles({
    explore_lists: {
        display: "flex",
        flexDirection: "column",
        alignItems: "start",
        padding: "1rem 0",
    },
});

export const NavExploreList = () => {
    const classes = useStyles();
    return (
        <div className={classes.explore_lists} data-testid="explore">
            <NavDrop
                startIcon={<AccountBalanceOutlined />}
                title="Entrepreneurship"
                
            />
            <NavDrop
                startIcon={<PublicOutlined />}
                title="Economics"
                
            />
            <NavDrop
                startIcon={<BusinessCenterOutlined />}
                title="Corporate Culture"
            />
            <NavDrop
                startIcon={<EcoOutlined />}
                title="Nature & Environment"
            />
            <NavDrop
                startIcon={<LocalHospitalOutlined />}
                title="Health & Nutrition"
            />
            <NavDrop
                startIcon={<HourglassEmptyOutlined />}
                title="Productivity"
            />
        </div>
    );
};

