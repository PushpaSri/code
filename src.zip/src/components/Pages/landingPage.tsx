import React from "react";
import {FooterTemplate} from "../Templates/footerTemplate" 
import {HeaderTemplate} from "../Templates/headerTemplate"
import {HomeTemplate} from "../Templates/tabCheckTemplate"

export function LandingPage() {
    return (
        <div>
            <HeaderTemplate></HeaderTemplate>
            <HomeTemplate></HomeTemplate>
            {/* <FooterTemplate></FooterTemplate> */}
        </div>
    );
}

