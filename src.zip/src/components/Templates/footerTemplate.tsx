import React from "react";
import { Footer } from "../Organisms/footer";

export function FooterTemplate() {
    return (
        <div>
            <Footer></Footer>
        </div>
    );
}

