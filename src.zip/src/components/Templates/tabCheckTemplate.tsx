import React from "react";
import { TabCheck } from "../Organisms/tabCheck";

export function HomeTemplate() {
    return <TabCheck></TabCheck>;
}

