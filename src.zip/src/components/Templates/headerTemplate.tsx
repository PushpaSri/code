import React from "react";
import { Nav } from "../Organisms/Nav/navBar";

export function HeaderTemplate() {
    return <Nav></Nav>;
}

