import React from "react";

export const bookContext = React.createContext(null);
