/// <reference types="react-scripts" />

declare module 'office-ui-fabric-react/lib/Modal' {
    const Modal: React.StatelessComponent<IModalProps>;
   }
