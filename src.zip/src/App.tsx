import "./index.css";
import { theme } from "./theme";
import { ThemeProvider } from "@material-ui/core/styles";
import { LandingPage } from "./components/Pages/landingPage";
import { BrowserRouter as Router, Route } from "react-router-dom";
import { ExploreNav } from "./components/Organisms/Explore/navExplore";
import { TabCheck } from "./components/Organisms/tabCheck";  
const App = () => {
      const value = 0
    return (
        <Router>
            <ThemeProvider theme={theme}>
             <Route path="/" exact>
                 <LandingPage></LandingPage>
                </Route>
            </ThemeProvider>
        </Router>
    );
};

export default App;

