import { createTheme } from "@material-ui/core/styles";

export const theme = createTheme({
    palette: {
        primary: {
            main: "#2CE080",
        },
        secondary: {
            main: "#0365F2",
        }
        // ,
        // Grid: {
        //     boxShadow: "none",
        // },
    },
});

